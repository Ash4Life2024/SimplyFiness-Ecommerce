# Simply Fitness E-commerce
This is a high-tech, affiliate-powered e-commerce platform for dropshippers.

## Features
- Bulk affiliate apply system
- Smart AI tracking for approvals and revenue
- Seller dashboard with product sync and review management
