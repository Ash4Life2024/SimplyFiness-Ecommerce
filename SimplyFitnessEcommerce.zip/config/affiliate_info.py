# Auto-fill business information
business_name = 'Simply Fitness E-commerce'
contact_email = 'simplyfinessforever@gmail.com'
app_url = 'https://ashleypagie.created.app'
